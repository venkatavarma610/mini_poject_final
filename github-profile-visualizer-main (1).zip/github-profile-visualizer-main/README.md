# Github Profile Visualizer

A simple github profile search and visualizer written and tested in rescript with react

## Todo
- [ ] create a new page to list all the followers of a profile.
- [ ] search the repositories of a profile with sorting options
- [ ] accept arbitrary page as input on pagination component
- [ ] write tests to pagination component
